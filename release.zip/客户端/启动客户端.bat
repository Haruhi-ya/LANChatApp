@echo off
setlocal
set "DIR=%~dp0"
set "JAVAW_EXE=javaw"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JAVAW_EXE=%JAVA_HOME%\bin\javaw.exe"
start "" "%JAVAW_EXE%" -jar "%DIR%LanChat-Client.jar"
